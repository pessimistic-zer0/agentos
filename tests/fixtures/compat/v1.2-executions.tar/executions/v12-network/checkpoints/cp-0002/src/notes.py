NOTE = 'written by the v1.2 fixture'
