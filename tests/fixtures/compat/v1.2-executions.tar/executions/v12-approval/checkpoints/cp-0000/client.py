import os, sys, urllib.request
os.environ.pop("NO_PROXY", None); os.environ.pop("no_proxy", None)
for url in sys.argv[1:]:
    try:
        print(url, urllib.request.urlopen(url, timeout=5).read().decode())
    except Exception as e:
        print(url, "error", type(e).__name__)
